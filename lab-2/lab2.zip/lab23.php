<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorio 2.3</title>
</head>

<body>
    <?php
    print("<ul>\n");
    $i = 1;
    while ($i <= 10) {
        print("<li>Elemento $i </li>\n");
        $i++;
    }
    print("</ul>\n")
    ?>
</body>

</html>