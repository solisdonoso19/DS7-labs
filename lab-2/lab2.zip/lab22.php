<?php
include("noexiste.php");
// require("noexiste.php");
echo ("Hola, el script siguio!");
